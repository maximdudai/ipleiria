<?php


if (isset($_POST['numberOne']) && isset($_POST['numberTwo'])) {

  $numberOne = $_POST['numberOne'];
  $numberTwo = $_POST['numberTwo'];
  $option = $_POST['optionList'];

  $final_result = 0;

  function getResult($num1, $num2, $option)
  {

    switch ($option) {
      case '+':
        $final_result = $num1 + $num2;
        break;

      case '-':
        $final_result = $num1 - $num2;
        break;

      case 'x':
        $final_result = $num1 * $num2;
        break;

      case '/':
        $final_result = $num1 / $num2;
        break;
    }

    return "O resultado da $option de $num1 com o $num2 é $final_result";
  }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Calculator</title>
</head>

<body>

  <form action="calculadora.php" method="POST">

    <div class="number_one">
      <label for="numberOne">Number One: </label>
      <input type="number" name="numberOne">
    </div>

    <div class="number_two">
      <label for="numberTwo">Number Two: </label>
      <input type="number" name="numberTwo">
    </div>

    <div class="option">
      <select name="optionList" id="option_list">
        <option value="+" selected>+</option>
        <option value="-">-</option>
        <option value="x">x</option>
        <option value="/">/</option>
      </select>
    </div>

    <br>

    <div class="result">
      <button type="submit">Calcular</button>
    </div>

  </form>

  <?php
  if (isset($_POST['numberOne']) && isset($_POST['numberTwo'])) {
    if($_POST['numberOne'] == 0 || $_POST['numberTwo'] == 0) {
      
      if($_POST['optionList'] == 'x' || $_POST['optionList'] == '/') {
        echo '<br>Invalid numbers or option list';
        return;
      }

    } else {
      echo getResult($_POST['numberOne'], $_POST['numberTwo'], $_POST['optionList']);
    }
  }
  ?>

</body>

</html>