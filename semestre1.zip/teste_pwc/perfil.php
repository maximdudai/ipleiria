<?php 
 if (isset($_GET['username']) && isset($_GET['idade']) && isset($_GET['anoNascimento'])) {

  foreach($_GET as $key => $value) {
    if($key == 'username') {
      echo "<h2 class='username'>Utilizador: $value</h2>";
    } else {
      echo "<p>$key: $value</p>";
    }
  }

  // $idade = $_GET['idade'];
  // $username = $_GET['username'];
  // $anoNascimento = $_GET['anoNascimento'];

  // echo "<h2 class='username'>Utilizador: $username</h2>";
  // echo "<p>Idade: $idade</p>";
  // echo "<p>Ano de Nascimento: $anoNascimento</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Perfil</title>

  <link rel="stylesheet" href="style.css">
</head>
<body>
  
</body>
</html>
