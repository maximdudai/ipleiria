<?php 

  $authData = [
    'email' => 'cisco@gmail.com',
    'password' => 'irso2024'
  ];

  if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if($email == $authData['email'] && $password == $authData['password']) {
      echo 'Login efetuado com sucesso';
    
      //redirect user
      header('Location: dashboard.php');
      
    } else {
      echo 'Login ou senha incorretos';
    }

  }


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>teste IRSO</title>

  <style>
    form {
      display: flex;
      flex-direction: column;
      width: 300px;
      margin: 0 auto;
    }

    label {
      margin-top: 10px;
    }

    input {
      margin-top: 5px;
    }

    button {
      margin-top: 10px;
    }
  </style>

</head>
<body>
  
  <form action="index.php" method="post">

    <label for="email">Email</label>
    <input type="email" name="email" id="email">

    <label for="password">Senha</label>
    <input type="password" name="password" id="password">

    <button type="submit">Entrar</button>

  </form>

</body>
</html>