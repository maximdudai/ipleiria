<?php 

  

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  

  <?php 
    for($i = 1; $i <= 3; $i++) {
      echo '<a style="margin-left:15px; text-decoration:none;" href="history-sensor.php?tipo=1&id=' . $i . '">Sensor ' . $i . '</a> <br />';
    }
  ?>

    <hr>

    <?php 
      for($i = 1; $i <= 3; $i++) {
        echo '<a style="margin-left:15px; text-decoration:none;" href="history-sensor.php?tipo=2&id=' . $i . '">Atuador ' . $i . '</a> <br />';
      }
    ?>

    <hr>
    <h1>Historico das ultimas 10 imagens</h1>

    <a href="history-ss.php">Historico (imagens)</a>

      <br><br><br>

    <a href="index.php">Log Out</a>

</body>
</html>
