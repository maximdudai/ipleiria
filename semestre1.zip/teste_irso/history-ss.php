<?php

$img_path = 'imgs/packet.png';

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>

  <div class="container">
    <h1>Historico das ultimas 10 imagens</h1>

    <hr>

    <?php
      for ($i = 0; $i < 10; $i++) {
        echo "<img style='margin-left: 10px; border: 1px solid black; padding: 1px; width: 200px; heigth: 200px;' src='$img_path' alt='packet'>";
      }
    ?>
  <br>
  <br>
  <br>
    <a style="padding: 5px; border: 1px solid black; font-size: 1.5rem" href="dashboard.php">Voltar</a>
  </div>

</body>

</html>