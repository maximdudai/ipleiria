<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- refresh every 5 seconds -->
    <meta http-equiv="refresh" content="5">

    <title>Lab04 - Histórico da Temperatura</title>
</head>
<body>
<h1>Lab04 - Histórico da Temperatura</h1>
<div>
    <h3>Estado (Data de actualização)</h3>

    <p>
        <?php 
            foreach (file('files/temperatura/log.txt') as $line) {
                echo '<p>' . $line . '</p>';
            }    
        ?>        
    </p>
</div>
<br/>
<br/>
<br/>
<a href="index.html">Página Inicial</a>
</body>
</html>