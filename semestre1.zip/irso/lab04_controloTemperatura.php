<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="5">
    <title>Lab04 - Controlo Temperatura</title>
</head>
<body>
<h1>Lab04 - Controlo Temperatura</h1>
    <div>
        <h3>Temperatura Actual</h3>
        <p><?php
            echo $valor_temperatura = file_get_contents("files/temperatura/valor.txt");
            ?></p>
        <h3>Data de actualização da Temperatura</h3>
        <p><?php
            echo $hora_temperatura = file_get_contents("files/temperatura/hora.txt");
            ?></p>
        <h3>Estado do LED</h3>
        <p><?php
            $valorLed = file_get_contents("files/led/valor.txt");
            if($valorLed=="1"){
                echo '<img src="images/led-on.png" alt="Estado do LED: Ligado">';
            }else{
                echo '<img src="images/led-off.png" alt="Estado do LED: Desligado">';
            }
            ?></p>
        <h3>Data de actualização do LED</h3>
        <p><?php
            echo file_get_contents("files/led/data.txt");
            ?></p>
    </div>
    <br/>
    <br/>
    <br/>
<a href="index.html">Página Inicial</a>
</body>
</html>