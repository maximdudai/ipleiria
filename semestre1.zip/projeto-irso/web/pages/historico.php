<?php
function obterDadosSensoresAtuadores()
{
  $dados = file_get_contents("../api/data/data.json");
  return json_decode($dados, true);
}

if ($_SERVER['REQUEST_METHOD'] == "GET") {
  $dadosSensoresAtuadores = obterDadosSensoresAtuadores();
  $sensores = $dadosSensoresAtuadores['sensores'];
  $atuadores = $dadosSensoresAtuadores['atuadores'];

  if (isset($_GET["tipo"]) && isset($_GET["id"])) {
    $tipo_dado = ($_GET["tipo"] == 1) ? $sensores : $atuadores;
    $id = $_GET["id"];

    $dado = array_filter($tipo_dado, function ($item) use ($id) {
      return $item['id'] == $id;
    });

    if (!empty($dado)) {
      $dado = reset($dado);

      $estado_img = ($dado['estado'] == 'ligado') ? '<img src="../assets/led-on.png" alt="Ligado" width="20px" height="20px">' : '<img src="../assets/led-off.png" alt="Desligado" width="20px" height="20px">';

      echo '<p>' . ucfirst(($tipo_dado == $sensores) ? 'Sensor' : 'Atuador') . ' ' . $dado['id'] . ' (' . $dado['tipo'] . '): ' . $dado['valor'] . ' ' . $dado['unidade'] . ' - Estado: ' . $estado_img . '</p>';
    } else {
      http_response_code(403);
      echo ('{"erro": "ID de ' . (($tipo_dado == $sensores) ? 'sensor' : 'atuador') . ' inválido!"}' . PHP_EOL);
      exit();
    }
  } else {
    http_response_code(403);
    echo ('{"erro": "Parâmetros inválidos!"}' . PHP_EOL);
    exit();
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Estado dos Sensores e Atuadores</title>

  <style>
    * {
      text-align: center;
    }

    a {
      text-decoration: none;
      color: black;
      margin: 10px;
      padding: 5px;
      border: 1px solid black;
      border-radius: 5px;
      font-size: 1.5rem;
    }
  </style>
</head>

<body>
  <?php if (isset($tipo_dado)) : ?>
    <h1>Estado do <?php echo ($tipo_dado == $sensores) ? 'Sensor' : 'Atuador'; ?> com ID <?php echo $id; ?></h1>
  <?php endif; ?>

  <a href="../index.php">Voltar</a>

</body>

</html>