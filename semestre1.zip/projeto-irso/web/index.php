<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estado dos Sensores e Atuadores</title>

    <style>
        * {
            text-align:  center;
        }
        a {
            text-decoration: none;
            color: black;
            margin: 10px;
            padding: 5px;
            border: 1px solid black;
            border-radius: 5px;
        }
        a:hover {
            background-color: black;
            color: white;
        }

        .atuadoresLista, .sensoresLista {
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
        }
    </style>
</head>

<body>
<h1>Estado dos Sensores e Atuadores</h1>
    <div class="historicoSensores">
        <p style="font-size:1.5rem; border-bottom: 1px solid black;">Visualizar o historico dos Sensores</p>
        <div class="sensoresLista">
            <?php
            for ($i = 1; $i <= 6; $i++) {
                echo "<a href='pages/historico.php?tipo=1&id=$i'>Sensor (#$i)</a><br>";
            }
            ?>
        </div>

    </div>

    <div class="historicoAtuadores" style="margin-top: 10%;">
        <p style="font-size:1.5rem; border-bottom: 1px solid black;">Visualizar o historico dos Atuadores</p>
        <div class="atuadoresLista">
            <?php
            for ($i = 1; $i <= 6; $i++) {
                echo "<a href='pages/historico.php?tipo=2&id=$i'>Atuador (#$i)</a><br>";
            }
            ?>
        </div>
    </div>
</body>

</html>