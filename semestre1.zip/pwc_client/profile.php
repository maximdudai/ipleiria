<?php

  $cor = $_GET['cor'];
  $fundo = $_GET['fundo'];

  // from my-account.php

  $formName = $_POST['name'];
  $formEmail = $_POST['email'];

  if(isset($formName) && isset($formEmail)) {
    echo "<p>Olá, $formName! Bem-vindo(a)</p> <br>";
    echo "<p>O teu mail é: Email: $formEmail</p> <br> <hr>";
  }


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profile PHP - Ficha 8</title>

  <style>
    a {
      text-decoration: none;
    }
  </style>

</head>

<body style="background-color: <?php echo $fundo; ?>; color: <?php echo $cor; ?>;">

  <a href="profile.php?cor=blue&fundo=white">
    Ir para o meu Perfil Branco
  </a>

  <hr>

  <a href="profile.php?cor=red&fundo=black">
    Ir para o meu Perfil Preto
  </a>

</body>

</html>