<?php 

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My acc - Ficha 8 - PHP</title>
</head>
<body>

  <form action="profile.php" method="post">

    <label for="name">Username:</label>
    <input type="text" name="name" id="formName">

    <label for="email">Email:</label>
    <input type="email" name="email" id="formEmail">

    <input type="submit" value="Submit">

  </form>


</body>
</html>